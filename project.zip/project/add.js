const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3000;

const conncetion = mysql.createConnection({
    host: 'localhost',
    user: 'sackna',
    password: '123456',
    database: 'dbpj',
});


conncetion.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err);
        return;
    }
    console.log('Connected to MySQL');
});


app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/saveTransaction', (req, res) => {
    const { name, surname, position, email, number } = req.body;
    res.send('Transaction saved successfully');
});

app.listen(port, () => {
    console.log('Server is running on port ' + port);
});